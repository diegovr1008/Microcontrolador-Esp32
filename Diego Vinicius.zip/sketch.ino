#include <WiFi.h> //Permite conectar o ESP32 ao WiFi
#include <WiFiClientSecure.h> //Permite conexão segura com o servidor
#include <PubSubClient.h> //Permite usar o MQTT para enviar e receber mensagens

#define ID_MQTT "SENAI_IOT01" //Nome do dispositivo no MQTT
#define pubSensor1IotSenai "Sensor1IotSenai" //Tópico para enviar dados do sensor
#define subLed1IotSenai "Led1IotSenai" //Tópico para receber comandos do LED
#define USERNAME_MQTT "SENAI_IOT01_web_client" // Login do Servidor
#define PASSWORD_MQTT "Aa123456789" // Senha do servidor
#define LED_PIN 25 //Pino onde o LED está ligado

const char* SSID = "Wokwi-GUEST"; //Nome da rede WiFi usada no simulador
const char* BROKER_MQTT = "52068913ceb040eb8f97f47fd7e906fd.s1.eu.hivemq.cloud";//Endereço do servidor MQTT

WiFiClientSecure wifiClient; //Cria uma conexão com a internet
PubSubClient MQTT(wifiClient);//Cria o ciente que vai usar a conexão

bool ledState = false; // Variavel que indica o estado do LED

void setLed(bool estado) {                //Função que liga ou desliga o LED
  digitalWrite(LED_PIN, estado ? HIGH : LOW);
}

void callback(char* topic, byte* payload, unsigned int length) {  // Função que recebe as msgs do MQTT e converte em texto
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];

  bool novoEstado = (msg == "1" || msg == "ON"); // Verifica se a mensagem é "1" ou "ON"
  ledState = novoEstado;
  setLed(ledState);
  Serial.println("LED " + String(ledState ? "ON" : "OFF") + " (MQTT)"); //Mostra no monitor se o LED está ON ou OFF
}

void setup() {
  Serial.begin(115200); //Inicia o monitor
  delay(1000);

  pinMode(LED_PIN, OUTPUT); //Define o pino do LED como saída
  digitalWrite(LED_PIN, LOW);

  WiFi.begin(SSID, ""); //Conecta ao WiFi
  wifiClient.setInsecure();
  MQTT.setServer(BROKER_MQTT, 8883); //Define o servidor
  MQTT.setCallback(callback); //Define a função que será executada quando chegar uma mensagem
}

void loop() { //Verifica o tempo todo se o WiFi está conectado
  if (WiFi.status() != WL_CONNECTED) {
    delay(500);
    return;
  }

  if (!MQTT.connected()) {
    if (MQTT.connect(ID_MQTT, USERNAME_MQTT, PASSWORD_MQTT)) {  // Se não tiver conectado tenta conectar
      MQTT.subscribe(subLed1IotSenai); //Se inscreve no tópico
      Serial.println("MQTT OK");
    }
  }

  MQTT.loop(); //Mantém a comunicação funcionando
}